/*
Samsung Galaxy S25 Ultra rugged 3D-printable case, standalone version.
Units: millimeters. Designed as a printable prototype with adjustable tolerances.
Part selector: set part = "assembly", "rear_shell", "front_bezel", or "all_flat".

Device reference envelope:
- Phone body: 77.6 W x 162.8 H x 8.2 T mm
- This model allows 0.35 mm side clearance and extra camera-area clearance.

Hardware suggestion:
- 6x M2.5 x 8-10 mm socket-head screws
- Optional M2.5 heat-set inserts in rear shell bosses, OD about 4.2 mm
- Print rear shell on its back; print bezel face-up.
*/

$fn = 48;
part = "assembly"; // "assembly", "rear_shell", "front_bezel", "all_flat"

// ---- Device / fit parameters ----
phone_w = 77.6;
phone_h = 162.8;
phone_t = 8.2;
clearance_xy = 0.35;
phone_corner_r = 7.0;

// ---- Case parameters ----
side_wall = 2.35;
bumper_extra = 1.35;
back_thick = 2.15;
side_height = 7.25;      // rear tray rises this far around the phone body
front_bezel_t = 2.05;
front_lip_overlap = 1.7; // bezel overlaps inward onto screen edge
outer_corner_r = 11.5;
inner_corner_r = phone_corner_r + clearance_xy;

case_w = phone_w + 2*(clearance_xy + side_wall + bumper_extra);
case_h = phone_h + 2*(clearance_xy + side_wall + bumper_extra);
case_z = back_thick + side_height;
inner_w = phone_w + 2*clearance_xy;
inner_h = phone_h + 2*clearance_xy;

// Screw boss positions. Kept outside the phone pocket but inside bumper mass.
screw_x = case_w/2 - 6.3;
screw_y_top = case_h/2 - 15.5;
screw_y_mid = 0;
screw_y_bot = -case_h/2 + 15.5;
screw_positions = [
    [ screw_x, screw_y_top], [-screw_x, screw_y_top],
    [ screw_x, screw_y_mid], [-screw_x, screw_y_mid],
    [ screw_x, screw_y_bot], [-screw_x, screw_y_bot]
];

// ---- 2D helpers ----
module rounded_rect_2d(w,h,r){
    hull(){
        translate([ w/2-r,  h/2-r]) circle(r=r);
        translate([-w/2+r,  h/2-r]) circle(r=r);
        translate([ w/2-r, -h/2+r]) circle(r=r);
        translate([-w/2+r, -h/2+r]) circle(r=r);
    }
}

module rounded_box(w,h,z,r){
    linear_extrude(height=z) rounded_rect_2d(w,h,r);
}

module screw_hole_through(z=20){
    cylinder(h=z, r=1.55, center=true); // M2.5 clearance with print allowance
}

module insert_pocket(z=4.8){
    cylinder(h=z, r=2.25, center=false); // 4.5 mm OD heat-set insert pocket
}

module rear_shell(){
    difference(){
        union(){
            // Main rugged tray body
            rounded_box(case_w, case_h, case_z, outer_corner_r);

            // Extra corner armor pads, blended by overlap for slicer union
            for (sx=[-1,1], sy=[-1,1])
                translate([sx*(case_w/2-8.5), sy*(case_h/2-8.5), 0])
                    cylinder(h=case_z+1.0, r=9.5, center=false);

            // Raised camera guard ring around the broad clearance opening
            translate([-19.0, phone_h/2-34.0, 0])
                difference(){
                    rounded_box(40.0, 68.0, back_thick+1.8, 7.0);
                    translate([0,0,-0.1]) rounded_box(34.0, 61.5, back_thick+2.2, 5.2);
                }

            // Rear screw bosses for inserts
            for (p=screw_positions)
                translate([p[0], p[1], back_thick]) cylinder(h=side_height-0.4, r=3.65, center=false);
        }

        // Phone pocket; leaves the back floor intact
        translate([0,0,back_thick])
            rounded_box(inner_w, inner_h, side_height+0.4, inner_corner_r);

        // Wide screen/front clearance through upper part of tray lip
        translate([0,0,back_thick+3.0])
            rounded_box(phone_w-2.0, phone_h-2.0, side_height+1.0, inner_corner_r-0.8);

        // Broad camera window, intentionally generous so exact lens islands are not blocked
        translate([-19.0, phone_h/2-34.0, -0.5])
            rounded_box(34.0, 61.5, back_thick+4.5, 5.2);

        // Button relief on right side: volume + power grouped long window
        translate([case_w/2-1.2, 18, back_thick+4.3])
            cube([5.0, 58.0, 7.0], center=true);

        // USB-C / speaker / S-Pen bottom clearance as one service opening
        translate([0, -case_h/2+1.0, back_thick+3.6])
            cube([58.0, 6.0, 7.5], center=true);

        // Top microphone relief
        translate([0, case_h/2-1.0, back_thick+4.0])
            cube([28.0, 5.0, 6.0], center=true);

        // Lanyard holes through lower left bumper
        translate([-case_w/2+7.0, -case_h/2+24.0, 4.5]) rotate([90,0,0]) cylinder(h=10, r=1.8, center=true);
        translate([-case_w/2+7.0, -case_h/2+14.0, 4.5]) rotate([90,0,0]) cylinder(h=10, r=1.8, center=true);

        // Through holes and insert pockets
        for (p=screw_positions){
            translate([p[0], p[1], case_z/2]) screw_hole_through(z=case_z+4);
            translate([p[0], p[1], back_thick+0.15]) insert_pocket(z=5.1);
        }
    }
}

module front_bezel(){
    difference(){
        union(){
            rounded_box(case_w, case_h, front_bezel_t, outer_corner_r);
            // Small underside registration rib drops into rear tray
            translate([0,0,-1.25])
                difference(){
                    rounded_box(inner_w+2.3, inner_h+2.3, 1.3, inner_corner_r+1.2);
                    translate([0,0,-0.1]) rounded_box(inner_w-2.2, inner_h-2.2, 1.6, inner_corner_r-1.0);
                }
        }
        // Screen opening. Leaves a protective lip around glass.
        translate([0,0,-0.2])
            rounded_box(phone_w - 2*front_lip_overlap, phone_h - 2*front_lip_overlap, front_bezel_t+1.8, phone_corner_r-1.0);

        // Screw clearance/counterbores
        for (p=screw_positions){
            translate([p[0], p[1], 0.6]) cylinder(h=front_bezel_t+2.0, r=1.55, center=true);
            translate([p[0], p[1], front_bezel_t-0.75]) cylinder(h=1.7, r=2.85, center=false);
        }

        // Keep right button access open through bezel side too
        translate([case_w/2-1.2, 18, 0.8]) cube([5.0, 58.0, 4.5], center=true);
        // Keep bottom port area open
        translate([0, -case_h/2+1.0, 0.8]) cube([58.0, 6.0, 4.5], center=true);
    }
}

module ghost_phone(){
    color([0.1,0.1,0.1,0.28]) translate([0,0,back_thick]) rounded_box(phone_w, phone_h, phone_t, phone_corner_r);
    color([0.03,0.03,0.03,0.4]) translate([0,0,back_thick+phone_t]) rounded_box(phone_w-3, phone_h-3, 0.35, phone_corner_r-1);
    color([0,0,0,0.35]) translate([-19.0, phone_h/2-34.0, back_thick+phone_t-0.3]) rounded_box(33, 60, 1.2, 5);
}

module assembly(){
    color([0.08,0.08,0.08]) rear_shell();
    color([0.16,0.16,0.16]) translate([0,0,case_z+0.25]) front_bezel();
    ghost_phone();
}

if (part == "rear_shell") rear_shell();
else if (part == "front_bezel") front_bezel();
else if (part == "all_flat") {
    translate([-case_w/2-6,0,0]) rear_shell();
    translate([ case_w/2+6,0,0]) front_bezel();
}
else assembly();
