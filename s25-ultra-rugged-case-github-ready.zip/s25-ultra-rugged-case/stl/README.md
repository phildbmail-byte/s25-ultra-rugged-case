# STL Exports

Export final printable STL files here from `cad/s25_ultra_rugged_case.scad`.

Recommended names:

- `back_shell.stl`
- `front_bezel.stl`
- `button_insert_power.stl`
- `button_insert_volume.stl`
