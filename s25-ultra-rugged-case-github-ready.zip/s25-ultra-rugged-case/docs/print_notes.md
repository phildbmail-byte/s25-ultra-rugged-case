# Print Notes

## Recommended Materials

- **PETG:** Good first choice for durability and ease of printing.
- **ASA/ABS:** Better heat resistance, but requires enclosure and ventilation.
- **TPU:** Best impact absorption, but requires more tuning and may need lower clearances.
- **Tough PLA/PLA+:** Easy to print, but less heat-resistant in cars or outdoor use.

## First Test Print

Before printing the full case, slice a 20-30 mm tall corner section around the phone cavity and one button/cutout section. Confirm:

- Phone slides in without force.
- The front lip clears any screen protector.
- Side buttons remain usable.
- USB-C cable fits the bottom cutout.
- Camera lenses and flash are not blocked.

## Fit Tuning

Start by adjusting `clearance_xy` in the SCAD file.

- Rigid materials: `0.45-0.70 mm` total clearance is usually safer.
- Flexible materials: `0.25-0.45 mm` may be sufficient.
- Poorly calibrated printers may need more clearance.

## Hardware

A future revision should use one of these fastening methods:

- M2 self-tapping screws into printed bosses.
- M2 heat-set inserts.
- Captive printed clips for a no-hardware version.

## Orientation

Suggested orientation:

- Rear shell: back face down.
- Front bezel: front face down or split into halves if warping occurs.
- Button inserts: print flat, high wall count.

Supports may be required depending on the exact exported modules.
