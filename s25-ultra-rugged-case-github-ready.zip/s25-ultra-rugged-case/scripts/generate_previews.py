import numpy as np
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d.art3d import Poly3DCollection
from pathlib import Path

phone_w, phone_h, phone_t = 77.6, 162.8, 8.2
clearance, side_wall, bumper, back, side_h, bezel_t = 0.35, 2.35, 1.35, 2.15, 7.25, 2.05
case_w = phone_w + 2*(clearance+side_wall+bumper)
case_h = phone_h + 2*(clearance+side_wall+bumper)
case_z = back + side_h


def rounded_rect_points(w,h,r,n=10):
    pts=[]
    centers=[(w/2-r,h/2-r),(-w/2+r,h/2-r),(-w/2+r,-h/2+r),(w/2-r,-h/2+r)]
    angles=[np.linspace(0,np.pi/2,n),np.linspace(np.pi/2,np.pi,n),np.linspace(np.pi,3*np.pi/2,n),np.linspace(3*np.pi/2,2*np.pi,n)]
    # reorder clockwise-ish from top right arc
    pts=[]
    for (cx,cy),angs in zip(centers, angles):
        for a in angs:
            pts.append((cx+r*np.cos(a), cy+r*np.sin(a)))
    return np.array(pts)

def add_prism(ax, xy, z0, z1, alpha=1.0):
    bottom=[(x,y,z0) for x,y in xy]
    top=[(x,y,z1) for x,y in xy]
    faces=[top,bottom[::-1]]
    for i in range(len(xy)):
        j=(i+1)%len(xy)
        faces.append([bottom[i], bottom[j], top[j], top[i]])
    pc=Poly3DCollection(faces, alpha=alpha, linewidths=0.35, edgecolors='k')
    ax.add_collection3d(pc)
    return pc

def add_box(ax, center, size, alpha=1.0):
    x,y,z=center; dx,dy,dz=size
    xs=[x-dx/2,x+dx/2]; ys=[y-dy/2,y+dy/2]; zs=[z-dz/2,z+dz/2]
    verts=[
        [(xs[0],ys[0],zs[0]),(xs[1],ys[0],zs[0]),(xs[1],ys[1],zs[0]),(xs[0],ys[1],zs[0])],
        [(xs[0],ys[0],zs[1]),(xs[1],ys[0],zs[1]),(xs[1],ys[1],zs[1]),(xs[0],ys[1],zs[1])],
        [(xs[0],ys[0],zs[0]),(xs[1],ys[0],zs[0]),(xs[1],ys[0],zs[1]),(xs[0],ys[0],zs[1])],
        [(xs[1],ys[0],zs[0]),(xs[1],ys[1],zs[0]),(xs[1],ys[1],zs[1]),(xs[1],ys[0],zs[1])],
        [(xs[1],ys[1],zs[0]),(xs[0],ys[1],zs[0]),(xs[0],ys[1],zs[1]),(xs[1],ys[1],zs[1])],
        [(xs[0],ys[1],zs[0]),(xs[0],ys[0],zs[0]),(xs[0],ys[0],zs[1]),(xs[0],ys[1],zs[1])],
    ]
    pc=Poly3DCollection(verts, alpha=alpha, linewidths=0.3, edgecolors='k')
    ax.add_collection3d(pc)
    return pc

def draw_case(fname, exploded=False):
    fig=plt.figure(figsize=(8,9), dpi=180)
    ax=fig.add_subplot(111, projection='3d')
    outer=rounded_rect_points(case_w,case_h,11.5,14)
    inner=rounded_rect_points(phone_w+2*clearance,phone_h+2*clearance,7.35,12)
    screen=rounded_rect_points(phone_w-3.4, phone_h-3.4, 6.0, 12)
    # rear body approximation as slab + inner pocket visual
    add_prism(ax, outer, 0, case_z, .92)
    add_prism(ax, inner, back, case_z+0.05, .15)
    # camera guard/block and opening
    cam_outer=rounded_rect_points(40,68,7,10)+np.array([-19,phone_h/2-34])
    cam_inner=rounded_rect_points(34,61.5,5,10)+np.array([-19,phone_h/2-34])
    add_prism(ax, cam_outer, 0, back+1.8, .9)
    add_prism(ax, cam_inner, -0.1, back+2.0, .18)
    # corner bumpers and screw bosses as cylinders approximated by prisms
    for sx in [-1,1]:
        for sy in [-1,1]:
            pts=rounded_rect_points(15,15,7.5,8)+np.array([sx*(case_w/2-8.5), sy*(case_h/2-8.5)])
            add_prism(ax, pts, 0, case_z+1, .9)
    screw_x=case_w/2-6.3
    for x in [screw_x, -screw_x]:
        for y in [case_h/2-15.5, 0, -case_h/2+15.5]:
            circle=np.array([(x+3.65*np.cos(t), y+3.65*np.sin(t)) for t in np.linspace(0,2*np.pi,24)])
            add_prism(ax,circle,back,case_z-.4,.9)
    # front bezel above
    zoff=case_z+10 if exploded else case_z+0.25
    add_prism(ax, outer, zoff, zoff+bezel_t, .82)
    add_prism(ax, screen, zoff-0.1, zoff+bezel_t+0.2, .18)
    # ghost phone
    phone=rounded_rect_points(phone_w,phone_h,7,12)
    add_prism(ax, phone, back, back+phone_t, .18)
    # button/port callouts as translucent boxes to show openings
    add_box(ax,(case_w/2,18,back+4.3),(4,58,7),.22)
    add_box(ax,(0,-case_h/2+1,back+3.6),(58,5,7),.22)
    ax.set_xlim(-case_w*.65, case_w*.65); ax.set_ylim(-case_h*.6, case_h*.6); ax.set_zlim(0,case_z+bezel_t+(18 if exploded else 3))
    ax.set_box_aspect((case_w,case_h,case_z+bezel_t+(18 if exploded else 3)))
    ax.view_init(elev=28, azim=-55)
    ax.set_axis_off()
    title='Samsung Galaxy S25 Ultra rugged 3D-printable case — exploded assembly' if exploded else 'Samsung Galaxy S25 Ultra rugged 3D-printable case — proposed design'
    ax.set_title(title, pad=10, fontsize=12)
    plt.tight_layout()
    fig.savefig(fname, bbox_inches='tight', pad_inches=.1)
    plt.close(fig)

out=Path('/mnt/data')
draw_case(out/'s25_ultra_case_preview.png', False)
draw_case(out/'s25_ultra_case_exploded_preview.png', True)
