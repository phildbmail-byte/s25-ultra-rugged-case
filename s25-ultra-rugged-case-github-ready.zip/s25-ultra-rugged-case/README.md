# Samsung Galaxy S25 Ultra Rugged 3D Printable Case

A rugged, multi-piece 3D-printable case concept for the Samsung Galaxy S25 Ultra. The design is standalone and does **not** depend on the Juggernaut mounting system.

This repository contains the parametric OpenSCAD source file, preview renders, print notes, and a recommended project structure for future STL exports and revisions.

## Preview

![Case preview](images/preview.png)

![Exploded preview](images/exploded_preview.png)

![Layout preview](images/layout_preview.png)

## Design Goals

- Fit the real Samsung Galaxy S25 Ultra body envelope.
- Rugged corner protection with raised bumper geometry.
- Multi-piece printable assembly.
- Raised screen lip and raised camera protection.
- Open access for USB-C, speaker/mic regions, S Pen, side buttons, and camera cluster.
- Parametric CAD so tolerances can be adjusted for different printers/materials.

## Device Reference Dimensions

The working phone envelope used by the model is:

- Width: `77.6 mm`
- Height: `162.8 mm`
- Body thickness: `8.2 mm`
- Approximate camera bump allowance: `9.1 mm`

The CAD includes configurable clearance values to account for real-world print variation.

## Repository Structure

```text
.
├── cad/
│   └── s25_ultra_rugged_case.scad
├── docs/
│   └── print_notes.md
├── images/
│   ├── preview.png
│   ├── exploded_preview.png
│   └── layout_preview.png
├── scripts/
│   └── generate_previews.py
├── stl/
│   └── README.md
├── exports/
│   └── README.md
├── .gitignore
├── LICENSE
└── README.md
```

## Printing Recommendations

This is a first-pass functional prototype. Print a small edge/corner test before committing to the full case.

Recommended starting settings:

| Setting | Recommendation |
|---|---:|
| Material | PETG, ASA, TPU, or tough PLA |
| Layer height | 0.16-0.24 mm |
| Walls/perimeters | 4+ |
| Infill | 25-40% gyroid/cubic |
| Supports | Depends on orientation |
| Nozzle | 0.4-0.6 mm |

For rigid materials, increase device clearance if the phone fit is tight. For TPU, reduce clearance slightly if the fit is loose.

## Adjustable Parameters

Open `cad/s25_ultra_rugged_case.scad` and tune these first:

```scad
clearance_xy = 0.45;
clearance_z = 0.35;
wall = 2.4;
corner_bumper = 4.6;
lip_height = 1.2;
```

Suggested tuning:

- Too tight: increase `clearance_xy` by `0.15-0.25 mm`.
- Too loose: decrease `clearance_xy` by `0.10-0.20 mm`.
- Screen protector interference: increase inner screen opening or reduce `lip_height`.
- Camera interference: increase camera clearance or camera boss height.

## Exporting STL Files

Open the SCAD file in OpenSCAD, choose the desired part/module, render, then export STL.

Suggested STL names:

```text
stl/back_shell.stl
stl/front_bezel.stl
stl/button_insert_power.stl
stl/button_insert_volume.stl
```

## Assembly Concept

The design is intended as a multi-piece case:

1. Place the phone into the rear shell.
2. Add optional button inserts if printed separately.
3. Install the front bezel.
4. Fasten with small screws or heat-set inserts depending on your revision.

M2 or M2.5 hardware is recommended for future refinement.

## Status

Prototype concept. Not yet verified against a physical Galaxy S25 Ultra or a 3D scan.

## Safety / Fit Disclaimer

This model may require tuning before use. Test fit carefully and do not force the phone into a print. Sharp edges, poor tolerances, or unsuitable materials can damage a device.
